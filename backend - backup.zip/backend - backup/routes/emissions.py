# backend/routes/emissions.py
from fastapi import APIRouter, Depends, HTTPException, status, Query
from typing import Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel
from auth import AuthUser, require_org_member
from database import get_supabase_client
from auth import AuthUser, require_auth, require_org_member, require_org_admin

router = APIRouter(prefix="/api", tags=["Emissions"])

# ==========================================
# PYDANTIC MODELS
# ==========================================

class EmissionCreate(BaseModel):
    organization_id: str
    asset_id: Optional[str] = None
    defra_factor_id: Optional[str] = None
    start_date: str
    end_date: str
    raw_quantity: float
    calculated_kg_co2e: float
    metadata: Optional[Dict[str, Any]] = None

# ==========================================
# ENDPOINTS
# ==========================================

@router.post("/emissions")
async def create_emission_record(
    emission_data: EmissionCreate,
    current_user: AuthUser = Depends(require_org_member())
):
    """
    Create a new emission record.
    Used by ManualEntryStandalone to save manually entered data.
    """
    try:
        supabase = get_supabase_client()
        
        # Verify organization access
        if current_user.organization_id != emission_data.organization_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You don't have access to this organization"
            )
        
        # Prepare record
        now = datetime.now().isoformat()
        
        # ✅ Fix: Build metadata properly
        metadata = {
            'created_by_email': current_user.email,
            'created_by_role': current_user.role,
            'source': 'manual_entry',
            'entry_timestamp': now
        }
        
        # Add custom metadata if provided
        if emission_data.metadata:
            metadata.update(emission_data.metadata)
        
        record = {
            'organization_id': emission_data.organization_id,
            'asset_id': emission_data.asset_id,
            'defra_factor_id': emission_data.defra_factor_id,
            'start_date': emission_data.start_date,
            'end_date': emission_data.end_date,
            'raw_quantity': emission_data.raw_quantity,
            'calculated_kg_co2e': emission_data.calculated_kg_co2e,
            'created_by_user_id': current_user.user_id,
            'created_at': now,
            'metadata': metadata
        }
        
        result = supabase.from_('emissions_logs') \
            .insert(record) \
            .execute()
        
        if not result.data:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to save emission record"
            )
        
        return {
            "success": True,
            "message": "Emission record saved successfully",
            "emission_id": result.data[0]['id'],
            "record": result.data[0]
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Error creating emission record: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to save emission record: {str(e)}"
        )

@router.get("/emissions")
async def get_emissions(
    start_date: Optional[str] = Query(None, description="Filter by start date (YYYY-MM-DD)"),
    end_date: Optional[str] = Query(None, description="Filter by end date (YYYY-MM-DD)"),
    asset_id: Optional[str] = Query(None, description="Filter by asset ID"),
    scope: Optional[str] = Query(None, description="Filter by scope (1, 2, or 3)"),
    limit: int = Query(100, ge=1, le=1000, description="Items per page"),
    offset: int = Query(0, ge=0, description="Offset for pagination"),
    current_user: AuthUser = Depends(require_org_member())
):
    """
    Get emissions records for the current user's organization.
    """
    try:
        supabase = get_supabase_client()
        
        org_id = current_user.organization_id
        if not org_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="User is not associated with an organization"
            )
        
        query = supabase.from_('emissions_logs') \
            .select('''
                id,
                start_date,
                end_date,
                raw_quantity,
                calculated_kg_co2e,
                metadata,
                created_at,
                created_by_user_id,
                assets (
                    id,
                    name,
                    type
                ),
                defra_conversion_factors (
                    id,
                    activity_type,
                    co2e_multiplier,
                    reporting_year
                )
            ''') \
            .eq('organization_id', org_id) \
            .order('start_date', desc=True)
        
        if start_date:
            query = query.gte('start_date', start_date)
        if end_date:
            query = query.lte('end_date', end_date)
        if asset_id:
            query = query.eq('asset_id', asset_id)
        if scope:
            query = query.contains('metadata', {'scope': scope})
        
        # Get total count
        count_query = query.clone()
        count_result = count_query.select('id', count='exact').execute()
        total = count_result.count or 0
        
        result = query.range(offset, offset + limit - 1).execute()
        
        # Format records
        records = []
        for record in result.data:
            asset_data = record.get('assets', {})
            defra_data = record.get('defra_conversion_factors', {})
            
            records.append({
                'id': record['id'],
                'start_date': record['start_date'],
                'end_date': record['end_date'],
                'raw_quantity': record['raw_quantity'],
                'calculated_kg_co2e': record['calculated_kg_co2e'],
                'asset_id': record.get('asset_id'),
                'asset_name': asset_data.get('name') if asset_data else None,
                'asset_type': asset_data.get('type') if asset_data else None,
                'defra_factor_id': record.get('defra_factor_id'),
                'activity_type': defra_data.get('activity_type') if defra_data else None,
                'co2e_multiplier': defra_data.get('co2e_multiplier') if defra_data else None,
                'reporting_year': defra_data.get('reporting_year') if defra_data else None,
                'metadata': record.get('metadata', {}),
                'created_by_user_id': record.get('created_by_user_id'),
                'created_at': record.get('created_at')
            })
        
        return {
            "success": True,
            "records": records,
            "total": total,
            "limit": limit,
            "offset": offset
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Error getting emissions: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get emissions: {str(e)}"
        )

@router.delete("/emissions/{record_id}")
async def delete_emission_record(
    record_id: str,
    current_user: AuthUser = Depends(require_org_member())
):
    """
    Delete an emission record.
    """
    try:
        supabase = get_supabase_client()
        
        # Verify the record belongs to the user's organization
        record = supabase.from_('emissions_logs') \
            .select('organization_id') \
            .eq('id', record_id) \
            .maybe_single() \
            .execute()
        
        if not record.data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Record not found"
            )
        
        if record.data['organization_id'] != current_user.organization_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You don't have permission to delete this record"
            )
        
        result = supabase.from_('emissions_logs') \
            .delete() \
            .eq('id', record_id) \
            .execute()
        
        return {
            "success": True,
            "message": "Record deleted successfully",
            "record_id": record_id
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"❌ Error deleting emission record: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete emission record: {str(e)}"
        )
# Add to backend/routes/emissions.py

# ==========================================
# Emissions Update Endpoints
# ==========================================

class EmissionUpdate(BaseModel):
    start_date: Optional[str] = None
    end_date: Optional[str] = None
    raw_quantity: Optional[float] = None
    calculated_kg_co2e: Optional[float] = None
    metadata: Optional[Dict[str, Any]] = None

class BulkEmissionCreate(BaseModel):
    emissions: List[Dict[str, Any]]

@router.put("/emissions/{record_id}")
async def update_emission_record(
    record_id: str,
    update_data: EmissionUpdate,
    current_user: AuthUser = Depends(require_auth())
):
    """Update an existing emission record."""
    try:
        supabase = get_supabase_client()
        
        # Check if record exists and user has access
        existing = supabase.from_('emissions_logs') \
            .select('id, organization_id') \
            .eq('id', record_id) \
            .maybe_single() \
            .execute()
        
        if not existing.data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Emission record not found"
            )
        
        # Check organization access
        if not current_user.is_admin:
            member = supabase.from_('organization_members') \
                .select('id') \
                .eq('organization_id', existing.data['organization_id']) \
                .eq('user_id', current_user.id) \
                .maybe_single() \
                .execute()
            
            if not member.data:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Not authorized to update this record"
                )
        
        # Update record
        data = update_data.dict(exclude_none=True)
        data['updated_at'] = datetime.utcnow().isoformat()
        
        result = supabase.from_('emissions_logs') \
            .update(data) \
            .eq('id', record_id) \
            .execute()
        
        return {
            "success": True,
            "message": "Emission record updated successfully",
            "data": result.data[0] if result.data else None
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update emission record: {str(e)}"
        )

@router.post("/emissions/bulk")
async def bulk_create_emissions(
    bulk_data: BulkEmissionCreate,
    current_user: AuthUser = Depends(require_auth())
):
    """Bulk create emission records."""
    try:
        supabase = get_supabase_client()
        
        results = {
            'success_count': 0,
            'failed_count': 0,
            'errors': [],
            'data': []
        }
        
        for emission in bulk_data.emissions:
            try:
                # Validate required fields
                if not emission.get('organization_id'):
                    results['failed_count'] += 1
                    results['errors'].append({
                        'error': 'organization_id is required',
                        'data': emission
                    })
                    continue
                
                # Check organization access
                if not current_user.is_admin:
                    member = supabase.from_('organization_members') \
                        .select('id') \
                        .eq('organization_id', emission['organization_id']) \
                        .eq('user_id', current_user.id) \
                        .maybe_single() \
                        .execute()
                    
                    if not member.data:
                        results['failed_count'] += 1
                        results['errors'].append({
                            'error': 'Not authorized for this organization',
                            'data': emission
                        })
                        continue
                
                # Add created_by
                emission['created_by_user_id'] = current_user.id
                emission['created_at'] = datetime.utcnow().isoformat()
                
                result = supabase.from_('emissions_logs') \
                    .insert(emission) \
                    .execute()
                
                if result.data:
                    results['success_count'] += 1
                    results['data'].append(result.data[0])
                else:
                    results['failed_count'] += 1
                    results['errors'].append({
                        'error': 'Failed to create record',
                        'data': emission
                    })
                    
            except Exception as e:
                results['failed_count'] += 1
                results['errors'].append({
                    'error': str(e),
                    'data': emission
                })
        
        return {
            "success": True,
            "message": f"Bulk creation completed: {results['success_count']} successful, {results['failed_count']} failed",
            "data": results
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to bulk create emissions: {str(e)}"
        )

@router.get("/emissions/stats")
async def get_emission_stats(
    current_user: AuthUser = Depends(require_auth()),
    organization_id: Optional[str] = None
):
    """Get emission statistics."""
    try:
        supabase = get_supabase_client()
        
        query = supabase.from_('emissions_logs').select('*')
        
        if organization_id:
            query = query.eq('organization_id', organization_id)
        elif not current_user.is_admin:
            # Get user's organizations
            orgs = supabase.from_('organization_members') \
                .select('organization_id') \
                .eq('user_id', current_user.id) \
                .execute()
            
            if orgs.data:
                org_ids = [o['organization_id'] for o in orgs.data]
                query = query.in_('organization_id', org_ids)
        
        result = query.execute()
        
        if not result.data:
            return {
                "success": True,
                "data": {
                    "total_records": 0,
                    "total_emissions_kg_co2e": 0,
                    "by_scope": {},
                    "by_year": {}
                }
            }
        
        # Calculate stats
        total_emissions = sum(r.get('calculated_kg_co2e', 0) for r in result.data)
        
        stats = {
            'total_records': len(result.data),
            'total_emissions_kg_co2e': round(total_emissions, 2),
            'by_scope': {},
            'by_year': {}
        }
        
        # Group by year
        for record in result.data:
            if record.get('start_date'):
                year = record['start_date'].split('-')[0]
                stats['by_year'][year] = stats['by_year'].get(year, 0) + record.get('calculated_kg_co2e', 0)
        
        return {"success": True, "data": stats}
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get emission stats: {str(e)}"
        )

@router.get("/emissions/export")
async def export_emissions(
    current_user: AuthUser = Depends(require_auth()),
    organization_id: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None
):
    """Export emissions data as CSV."""
    try:
        supabase = get_supabase_client()
        
        query = supabase.from_('emissions_logs') \
            .select('*, organizations!left(name), assets!left(name, type)')
        
        if organization_id:
            query = query.eq('organization_id', organization_id)
        elif not current_user.is_admin:
            orgs = supabase.from_('organization_members') \
                .select('organization_id') \
                .eq('user_id', current_user.id) \
                .execute()
            
            if orgs.data:
                org_ids = [o['organization_id'] for o in orgs.data]
                query = query.in_('organization_id', org_ids)
        
        if start_date:
            query = query.gte('start_date', start_date)
        if end_date:
            query = query.lte('end_date', end_date)
        
        result = query.execute()
        
        if not result.data:
            return {
                "success": True,
                "message": "No data to export"
            }
        
        # Generate CSV
        import csv
        import io
        output = io.StringIO()
        writer = csv.writer(output)
        
        headers = ['id', 'organization_id', 'organization_name', 'asset_id', 'asset_name', 
                  'asset_type', 'start_date', 'end_date', 'raw_quantity', 'calculated_kg_co2e',
                  'created_by_user_id', 'created_at']
        writer.writerow(headers)
        
        for record in result.data:
            row = [
                record.get('id', ''),
                record.get('organization_id', ''),
                record.get('organizations', {}).get('name', '') if record.get('organizations') else '',
                record.get('asset_id', ''),
                record.get('assets', {}).get('name', '') if record.get('assets') else '',
                record.get('assets', {}).get('type', '') if record.get('assets') else '',
                record.get('start_date', ''),
                record.get('end_date', ''),
                record.get('raw_quantity', ''),
                record.get('calculated_kg_co2e', ''),
                record.get('created_by_user_id', ''),
                record.get('created_at', '')
            ]
            writer.writerow(row)
        
        from fastapi.responses import Response
        return Response(
            content=output.getvalue(),
            media_type="text/csv",
            headers={
                "Content-Disposition": f"attachment; filename=emissions_export_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv"
            }
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to export emissions: {str(e)}"
        )

@router.post("/emissions/verify")
async def verify_emissions(
    record_ids: List[str],
    current_user: AuthUser = Depends(require_auth())
):
    """Verify emission records (mark as verified)."""
    try:
        supabase = get_supabase_client()
        
        results = {
            'verified': 0,
            'failed': 0,
            'errors': []
        }
        
        for record_id in record_ids:
            try:
                # Check if record exists
                existing = supabase.from_('emissions_logs') \
                    .select('id, organization_id') \
                    .eq('id', record_id) \
                    .maybe_single() \
                    .execute()
                
                if not existing.data:
                    results['failed'] += 1
                    results['errors'].append({
                        'record_id': record_id,
                        'error': 'Record not found'
                    })
                    continue
                
                # Update record
                result = supabase.from_('emissions_logs') \
                    .update({
                        'verified_at': datetime.utcnow().isoformat(),
                        'verified_by': current_user.id,
                        'updated_at': datetime.utcnow().isoformat()
                    }) \
                    .eq('id', record_id) \
                    .execute()
                
                if result.data:
                    results['verified'] += 1
                else:
                    results['failed'] += 1
                    results['errors'].append({
                        'record_id': record_id,
                        'error': 'Failed to verify'
                    })
                    
            except Exception as e:
                results['failed'] += 1
                results['errors'].append({
                    'record_id': record_id,
                    'error': str(e)
                })
        
        return {
            "success": True,
            "message": f"Verification completed: {results['verified']} verified, {results['failed']} failed",
            "data": results
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to verify emissions: {str(e)}"
        )