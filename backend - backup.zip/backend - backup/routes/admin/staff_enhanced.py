# backend/routes/admin/staff_enhanced.py
"""
Enhanced staff management endpoints for performance tracking and activity monitoring.
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta
from auth import AuthUser, require_admin
from database import get_supabase_client

router = APIRouter(prefix="/api/admin/staff", tags=["Admin - Staff Enhanced"])

# ==========================================
# Pydantic Models
# ==========================================

class StaffPerformanceMetrics(BaseModel):
    staff_id: str
    name: str
    email: str
    role: str
    total_reviews_completed: int
    avg_review_time_seconds: Optional[float]
    accuracy_rate: Optional[float]
    current_workload: int
    completion_rate: float
    performance_score: float

class StaffActivityItem(BaseModel):
    date: str
    reviews_completed: int
    reviews_assigned: int
    avg_time: Optional[float]
    status: str

# ==========================================
# Staff Performance Endpoints
# ==========================================

@router.get("/performance")
async def get_staff_performance(
    current_user: AuthUser = Depends(require_admin()),
    days: int = Query(30, ge=1, le=365),
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0)
):
    """
    Get staff performance metrics.
    Returns aggregated performance data for all staff members.
    """
    try:
        supabase = get_supabase_client()
        
        # Get all staff profiles with their performance data
        staff_result = supabase.from_('staff_profiles') \
            .select('*') \
            .eq('is_active', True) \
            .range(offset, offset + limit - 1) \
            .execute()
        
        if not staff_result.data:
            return {
                "success": True,
                "data": [],
                "total": 0
            }
        
        performance_data = []
        
        for staff in staff_result.data:
            staff_id = staff['id']
            
            # Get reviews completed in the last N days
            start_date = (datetime.utcnow() - timedelta(days=days)).isoformat()
            
            reviews_result = supabase.from_('manual_review_queue') \
                .select('id, status, review_time_seconds, created_at, completed_at') \
                .eq('assigned_to', staff_id) \
                .gte('completed_at', start_date) \
                .execute()
            
            completed_reviews = [r for r in (reviews_result.data or []) if r.get('status') == 'completed']
            
            # Calculate metrics
            total_completed = len(completed_reviews)
            
            # Average review time
            review_times = [r.get('review_time_seconds', 0) for r in completed_reviews if r.get('review_time_seconds')]
            avg_time = sum(review_times) / len(review_times) if review_times else None
            
            # Accuracy rate (if available)
            accuracy = staff.get('accuracy_rate', 0)
            
            # Current workload
            workload_result = supabase.from_('staff_workload') \
                .select('assigned_reviews, in_progress_reviews') \
                .eq('staff_id', staff_id) \
                .eq('date', datetime.utcnow().date().isoformat()) \
                .maybe_single() \
                .execute()
            
            current_workload = 0
            if workload_result.data:
                current_workload = workload_result.data.get('assigned_reviews', 0) + workload_result.data.get('in_progress_reviews', 0)
            
            # Calculate completion rate (completed vs assigned)
            assigned_result = supabase.from_('manual_review_queue') \
                .select('id', count='exact') \
                .eq('assigned_to', staff_id) \
                .execute()
            
            total_assigned = len(assigned_result.data) if assigned_result.data else 0
            completion_rate = (total_completed / total_assigned * 100) if total_assigned > 0 else 0
            
            # Performance score (weighted combination)
            performance_score = 0
            if total_completed > 0:
                # Weight: 40% completion rate, 30% accuracy, 30% speed
                speed_score = 100 if avg_time and avg_time < 300 else max(0, 100 - (avg_time / 60)) if avg_time else 50
                performance_score = (completion_rate * 0.4) + (accuracy * 0.3) + (speed_score * 0.3)
            else:
                performance_score = 0
            
            performance_data.append({
                'staff_id': staff_id,
                'name': f"{staff.get('first_name', '')} {staff.get('last_name', '')}".strip() or staff.get('email', 'Unknown'),
                'email': staff.get('email', ''),
                'role': staff.get('role', ''),
                'total_reviews_completed': total_completed,
                'avg_review_time_seconds': avg_time,
                'accuracy_rate': accuracy,
                'current_workload': current_workload,
                'completion_rate': round(completion_rate, 2),
                'performance_score': round(performance_score, 2)
            })
        
        # Sort by performance score descending
        performance_data.sort(key=lambda x: x['performance_score'], reverse=True)
        
        return {
            "success": True,
            "data": performance_data,
            "total": len(performance_data)
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get staff performance: {str(e)}"
        )

@router.get("/activity")
async def get_staff_activity(
    current_user: AuthUser = Depends(require_admin()),
    staff_id: Optional[str] = None,
    days: int = Query(7, ge=1, le=90),
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0)
):
    """
    Get staff activity timeline.
    Shows daily activity for staff members.
    """
    try:
        supabase = get_supabase_client()
        
        # If staff_id provided, get specific staff activity
        if staff_id:
            # Verify staff exists
            staff_check = supabase.from_('staff_profiles') \
                .select('id') \
                .eq('id', staff_id) \
                .maybe_single() \
                .execute()
            
            if not staff_check.data:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Staff member not found"
                )
        
        # Build query for activity data
        query = supabase.from_('staff_workload')
        
        if staff_id:
            query = query.eq('staff_id', staff_id)
        
        # Get workload data for the last N days
        start_date = (datetime.utcnow() - timedelta(days=days)).date().isoformat()
        end_date = datetime.utcnow().date().isoformat()
        
        query = query.gte('date', start_date).lte('date', end_date)
        
        result = query.order('date', desc=True) \
            .range(offset, offset + limit - 1) \
            .execute()
        
        if not result.data:
            return {
                "success": True,
                "data": [],
                "total": 0
            }
        
        # Format activity data
        activity_data = []
        for record in result.data:
            # Get staff name
            staff_info = supabase.from_('staff_profiles') \
                .select('first_name, last_name, email') \
                .eq('id', record['staff_id']) \
                .maybe_single() \
                .execute()
            
            staff_name = "Unknown"
            if staff_info.data:
                staff_name = f"{staff_info.data.get('first_name', '')} {staff_info.data.get('last_name', '')}".strip() or staff_info.data.get('email', 'Unknown')
            
            # Determine status based on workload
            workload = record.get('assigned_reviews', 0) + record.get('in_progress_reviews', 0)
            if workload == 0:
                status = "idle"
            elif workload <= 3:
                status = "light"
            elif workload <= 6:
                status = "moderate"
            else:
                status = "heavy"
            
            activity_data.append({
                'date': record.get('date'),
                'staff_id': record.get('staff_id'),
                'staff_name': staff_name,
                'reviews_assigned': record.get('assigned_reviews', 0),
                'reviews_in_progress': record.get('in_progress_reviews', 0),
                'reviews_completed': record.get('completed_today', 0),
                'workload_score': record.get('workload_score', 0),
                'status': status
            })
        
        return {
            "success": True,
            "data": activity_data,
            "total": len(activity_data)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get staff activity: {str(e)}"
        )

@router.get("/performance/export")
async def export_staff_performance(
    current_user: AuthUser = Depends(require_admin()),
    days: int = Query(30, ge=1, le=365)
):
    """
    Export staff performance data as CSV.
    """
    try:
        # First get the performance data
        supabase = get_supabase_client()
        
        staff_result = supabase.from_('staff_profiles') \
            .select('*') \
            .eq('is_active', True) \
            .execute()
        
        if not staff_result.data:
            return {
                "success": True,
                "message": "No staff data to export"
            }
        
        # Build export data
        export_data = []
        start_date = (datetime.utcnow() - timedelta(days=days)).isoformat()
        
        for staff in staff_result.data:
            staff_id = staff['id']
            
            # Get reviews
            reviews_result = supabase.from_('manual_review_queue') \
                .select('id, status, review_time_seconds, completed_at') \
                .eq('assigned_to', staff_id) \
                .gte('completed_at', start_date) \
                .execute()
            
            completed_reviews = [r for r in (reviews_result.data or []) if r.get('status') == 'completed']
            total_completed = len(completed_reviews)
            
            review_times = [r.get('review_time_seconds', 0) for r in completed_reviews if r.get('review_time_seconds')]
            avg_time = sum(review_times) / len(review_times) if review_times else None
            
            # Get workload
            workload_result = supabase.from_('staff_workload') \
                .select('assigned_reviews, in_progress_reviews') \
                .eq('staff_id', staff_id) \
                .eq('date', datetime.utcnow().date().isoformat()) \
                .maybe_single() \
                .execute()
            
            current_workload = 0
            if workload_result.data:
                current_workload = workload_result.data.get('assigned_reviews', 0) + workload_result.data.get('in_progress_reviews', 0)
            
            export_data.append({
                'Staff ID': staff_id,
                'Name': f"{staff.get('first_name', '')} {staff.get('last_name', '')}".strip() or staff.get('email', 'Unknown'),
                'Email': staff.get('email', ''),
                'Role': staff.get('role', ''),
                'Reviews Completed': total_completed,
                'Avg Time (secs)': avg_time or 0,
                'Accuracy Rate': staff.get('accuracy_rate', 0),
                'Current Workload': current_workload
            })
        
        # Generate CSV
        import csv
        import io
        output = io.StringIO()
        writer = csv.writer(output)
        
        if export_data:
            headers = list(export_data[0].keys())
            writer.writerow(headers)
            
            for record in export_data:
                writer.writerow([record.get(h, '') for h in headers])
        
        from fastapi.responses import Response
        return Response(
            content=output.getvalue(),
            media_type="text/csv",
            headers={
                "Content-Disposition": f"attachment; filename=staff_performance_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv"
            }
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to export staff performance: {str(e)}"
        )
# Add to backend/routes/admin/staff_enhanced.py

# ==========================================
# Staff Activity Logging
# ==========================================

@router.get("/{staff_id}/activity-log")
async def get_staff_activity_log(
    staff_id: str,
    current_user: AuthUser = Depends(require_admin()),
    days: int = Query(30, ge=1, le=365),
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0)
):
    """Get detailed activity log for a staff member."""
    try:
        supabase = get_supabase_client()
        
        # Check if staff exists
        staff = supabase.from_('staff_profiles') \
            .select('id, first_name, last_name, email') \
            .eq('id', staff_id) \
            .maybe_single() \
            .execute()
        
        if not staff.data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Staff member not found"
            )
        
        # Get activity logs
        start_date = (datetime.utcnow() - timedelta(days=days)).isoformat()
        
        # Get review activities
        reviews = supabase.from_('manual_review_queue') \
            .select('id, file_name, status, created_at, completed_at, review_time_seconds') \
            .eq('assigned_to', staff_id) \
            .gte('created_at', start_date) \
            .order('created_at', desc=True) \
            .range(offset, offset + limit - 1) \
            .execute()
        
        # Get assignment history
        assignments = supabase.from_('review_assignment_history') \
            .select('*') \
            .eq('assigned_to', staff_id) \
            .gte('created_at', start_date) \
            .order('created_at', desc=True) \
            .range(offset, offset + limit - 1) \
            .execute()
        
        return {
            "success": True,
            "data": {
                "staff": staff.data,
                "reviews": reviews.data if reviews.data else [],
                "assignments": assignments.data if assignments.data else [],
                "total_reviews": len(reviews.data) if reviews.data else 0,
                "total_assignments": len(assignments.data) if assignments.data else 0
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get staff activity log: {str(e)}"
        )

@router.get("/{staff_id}/performance-history")
async def get_staff_performance_history(
    staff_id: str,
    current_user: AuthUser = Depends(require_admin()),
    months: int = Query(6, ge=1, le=24)
):
    """Get performance history for a staff member."""
    try:
        supabase = get_supabase_client()
        
        # Check if staff exists
        staff = supabase.from_('staff_profiles') \
            .select('id, first_name, last_name, email') \
            .eq('id', staff_id) \
            .maybe_single() \
            .execute()
        
        if not staff.data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Staff member not found"
            )
        
        # Get monthly performance data
        start_date = (datetime.utcnow() - timedelta(days=months*30)).isoformat()
        
        # Get completed reviews by month
        reviews = supabase.from_('manual_review_queue') \
            .select('completed_at, review_time_seconds, status') \
            .eq('assigned_to', staff_id) \
            .eq('status', 'completed') \
            .gte('completed_at', start_date) \
            .execute()
        
        monthly_data = {}
        total_reviews = 0
        total_time = 0
        
        if reviews.data:
            for review in reviews.data:
                if review.get('completed_at'):
                    month = review['completed_at'][:7]  # YYYY-MM
                    if month not in monthly_data:
                        monthly_data[month] = {
                            'month': month,
                            'completed': 0,
                            'total_time_seconds': 0,
                            'avg_time_seconds': 0
                        }
                    monthly_data[month]['completed'] += 1
                    monthly_data[month]['total_time_seconds'] += review.get('review_time_seconds', 0)
                    total_reviews += 1
                    total_time += review.get('review_time_seconds', 0)
        
        # Calculate averages
        for month, data in monthly_data.items():
            if data['completed'] > 0:
                data['avg_time_seconds'] = round(data['total_time_seconds'] / data['completed'], 2)
        
        history = {
            'staff': staff.data,
            'total_reviews': total_reviews,
            'avg_time_seconds': round(total_time / total_reviews, 2) if total_reviews > 0 else 0,
            'monthly_data': sorted(monthly_data.values(), key=lambda x: x['month'])
        }
        
        return {"success": True, "data": history}
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get staff performance history: {str(e)}"
        )

@router.post("/{staff_id}/reset-password")
async def reset_staff_password(
    staff_id: str,
    current_user: AuthUser = Depends(require_admin())
):
    """Reset staff member's password (send reset email)."""
    try:
        supabase = get_supabase_client()
        
        # Check if staff exists
        staff = supabase.from_('staff_profiles') \
            .select('id, email, first_name, last_name') \
            .eq('id', staff_id) \
            .maybe_single() \
            .execute()
        
        if not staff.data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Staff member not found"
            )
        
        # Generate reset token
        import secrets
        reset_token = secrets.token_urlsafe(32)
        
        # Store token (you'd have a password_reset_tokens table)
        # For now, we'll just return the token
        # In production, you'd send an email
        
        return {
            "success": True,
            "message": "Password reset email sent",
            "data": {
                "email": staff.data['email'],
                "reset_token": reset_token,
                "expires_in": "1 hour"
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to reset staff password: {str(e)}"
        )