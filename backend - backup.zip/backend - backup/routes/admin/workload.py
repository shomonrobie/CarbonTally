# backend/routes/admin/workload.py
"""
Staff workload and queue management endpoints.
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
from datetime import datetime, date
from auth import AuthUser, require_admin
from database import get_supabase_client

router = APIRouter(prefix="/api/admin", tags=["Admin - Workload"])

# ==========================================
# Pydantic Models
# ==========================================

class WorkloadSettingsUpdate(BaseModel):
    max_reviews_per_staff: Optional[int] = None
    sla_hours: Optional[int] = None
    auto_assign_enabled: Optional[bool] = None
    escalation_hours: Optional[int] = None
    priority_weights: Optional[Dict[str, float]] = None

class ReassignRequest(BaseModel):
    review_id: str
    assigned_to: str
    reason: Optional[str] = None

# ==========================================
# Workload Endpoints
# ==========================================

@router.get("/staff/workload")
async def get_staff_workload(
    current_user: AuthUser = Depends(require_admin()),
    date_filter: Optional[str] = None
):
    """Get workload for all staff."""
    try:
        supabase = get_supabase_client()
        
        query = supabase.from_('staff_workload') \
            .select('*, staff_profiles!left(first_name, last_name, email, role)')
        
        if date_filter:
            query = query.eq('date', date_filter)
        else:
            # Get today's workload
            query = query.eq('date', date.today().isoformat())
        
        result = query.order('workload_score', desc=True) \
            .execute()
        
        return {
            "success": True,
            "data": result.data,
            "total": len(result.data)
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get staff workload: {str(e)}"
        )

@router.get("/staff/workload/{staff_id}")
async def get_staff_workload_detail(
    staff_id: str,
    current_user: AuthUser = Depends(require_admin()),
    date_filter: Optional[str] = None
):
    """Get detailed workload for a specific staff member."""
    try:
        supabase = get_supabase_client()
        
        query = supabase.from_('staff_workload') \
            .select('*') \
            .eq('staff_id', staff_id)
        
        if date_filter:
            query = query.eq('date', date_filter)
        else:
            query = query.eq('date', date.today().isoformat())
        
        result = query.maybe_single() \
            .execute()
        
        if not result.data:
            # Create default workload record
            default_data = {
                'staff_id': staff_id,
                'date': date.today().isoformat(),
                'assigned_reviews': 0,
                'in_progress_reviews': 0,
                'pending_reviews': 0,
                'completed_today': 0,
                'workload_score': 0,
                'last_updated': datetime.utcnow().isoformat()
            }
            
            # Check if staff exists
            staff = supabase.from_('staff_profiles') \
                .select('id') \
                .eq('id', staff_id) \
                .maybe_single() \
                .execute()
            
            if not staff.data:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail="Staff member not found"
                )
            
            result = supabase.from_('staff_workload') \
                .insert(default_data) \
                .execute()
        
        return {"success": True, "data": result.data}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get staff workload detail: {str(e)}"
        )

# ==========================================
# Queue Settings Endpoints
# ==========================================

@router.get("/queue/settings")
async def get_queue_settings(
    current_user: AuthUser = Depends(require_admin())
):
    """Get queue settings."""
    try:
        supabase = get_supabase_client()
        
        result = supabase.from_('queue_settings') \
            .select('*') \
            .maybe_single() \
            .execute()
        
        if not result.data:
            # Return default settings
            return {
                "success": True,
                "data": {
                    'max_reviews_per_staff': 5,
                    'sla_hours': 48,
                    'auto_assign_enabled': True,
                    'escalation_hours': 24,
                    'priority_weights': {'high': 1.0, 'medium': 0.6, 'low': 0.3}
                }
            }
        
        return {"success": True, "data": result.data}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get queue settings: {str(e)}"
        )

@router.put("/queue/settings")
async def update_queue_settings(
    settings: WorkloadSettingsUpdate,
    current_user: AuthUser = Depends(require_admin())
):
    """Update queue settings."""
    try:
        supabase = get_supabase_client()
        
        # Check if settings exist
        existing = supabase.from_('queue_settings') \
            .select('id') \
            .maybe_single() \
            .execute()
        
        data = settings.dict(exclude_none=True)
        data['updated_at'] = datetime.utcnow().isoformat()
        data['updated_by'] = current_user.id
        
        if existing.data:
            result = supabase.from_('queue_settings') \
                .update(data) \
                .eq('id', existing.data['id']) \
                .execute()
        else:
            data['created_at'] = datetime.utcnow().isoformat()
            result = supabase.from_('queue_settings') \
                .insert(data) \
                .execute()
        
        return {
            "success": True,
            "message": "Queue settings updated successfully",
            "data": result.data[0] if result.data else None
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update queue settings: {str(e)}"
        )

# ==========================================
# Queue Stats Endpoints
# ==========================================

@router.get("/queue/stats")
async def get_queue_stats(
    current_user: AuthUser = Depends(require_admin())
):
    """Get queue statistics."""
    try:
        supabase = get_supabase_client()
        
        # Get queue counts by status
        queue_result = supabase.from_('manual_review_queue') \
            .select('status', count='exact') \
            .execute()
        
        # Get SLA breaches
        breach_result = supabase.from_('manual_review_queue') \
            .select('id', count='exact') \
            .eq('sla_breached', True) \
            .execute()
        
        # Get average review time
        avg_result = supabase.from_('manual_review_queue') \
            .select('review_time_seconds') \
            .not_.is_('review_time_seconds', 'null') \
            .execute()
        
        stats = {
            'total_in_queue': 0,
            'by_status': {},
            'sla_breaches': 0,
            'average_review_time_seconds': 0
        }
        
        if queue_result.data:
            for item in queue_result.data:
                stats['by_status'][item['status']] = stats['by_status'].get(item['status'], 0) + 1
                stats['total_in_queue'] += 1
        
        stats['sla_breaches'] = len(breach_result.data) if breach_result.data else 0
        
        if avg_result.data:
            times = [t['review_time_seconds'] for t in avg_result.data if t['review_time_seconds'] is not None]
            if times:
                stats['average_review_time_seconds'] = sum(times) / len(times)
        
        return {"success": True, "data": stats}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to get queue stats: {str(e)}"
        )

# ==========================================
# Reassignment Endpoints
# ==========================================

@router.post("/queue/reassign")
async def reassign_review(
    request: ReassignRequest,
    current_user: AuthUser = Depends(require_admin())
):
    """Reassign a review to another staff member."""
    try:
        supabase = get_supabase_client()
        
        # Check if review exists
        review = supabase.from_('manual_review_queue') \
            .select('*') \
            .eq('id', request.review_id) \
            .maybe_single() \
            .execute()
        
        if not review.data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Review not found"
            )
        
        # Check if staff exists
        staff = supabase.from_('staff_profiles') \
            .select('id') \
            .eq('id', request.assigned_to) \
            .maybe_single() \
            .execute()
        
        if not staff.data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Staff member not found"
            )
        
        # Update review
        update_data = {
            'assigned_to': request.assigned_to,
            'assigned_by': current_user.id,
            'status': 'assigned',
            'updated_at': datetime.utcnow().isoformat()
        }
        
        result = supabase.from_('manual_review_queue') \
            .update(update_data) \
            .eq('id', request.review_id) \
            .execute()
        
        # Log reassignment
        log_data = {
            'review_id': request.review_id,
            'assigned_by': current_user.id,
            'assigned_to': request.assigned_to,
            'previous_assigned_to': review.data.get('assigned_to'),
            'action': 'reassigned',
            'note': request.reason or f"Reassigned by {current_user.email}",
            'created_at': datetime.utcnow().isoformat()
        }
        
        supabase.from_('review_assignment_history') \
            .insert(log_data) \
            .execute()
        
        return {
            "success": True,
            "message": f"Review reassigned to staff member",
            "data": result.data[0] if result.data else None
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to reassign review: {str(e)}"
        )