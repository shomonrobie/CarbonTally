# backend/utils/__init__.py
from .email import (
    # Core
    send_email,
    
    # Existing email functions
    send_invitation_email,
    send_welcome_email,
    send_password_reset_email,
    send_emission_report_email,
    
    # New email functions
    send_beta_invite_email,
    send_feedback_acknowledgement_email,
    send_review_completion_email,
    send_bulk_invite_summary_email,
    
    # Helpers
    log_email,
    validate_email,
)
from .emissions import (
    ACTIVITY_TYPE_MAPPING,
    get_emission_factor,
    get_activity_category,
    calculate_emissions_with_defra,
    process_fuel_data,
    process_utility_data,
    process_scope3_data,
    extract_issues_from_result,
    has_low_confidence
)

__all__ = [
    # Email
    'send_email',
    'send_invitation_email',
    'send_welcome_email',
    'send_password_reset_email',
    'send_emission_report_email',
    'send_beta_invite_email',
    'send_feedback_acknowledgement_email',
    'send_review_completion_email',
    'send_bulk_invite_summary_email',
    'log_email',
    'validate_email',
    
    # Emissions
    'ACTIVITY_TYPE_MAPPING',
    'get_emission_factor',
    'get_activity_category',
    'calculate_emissions_with_defra',
    'process_fuel_data',
    'process_utility_data',
    'process_scope3_data',
    'extract_issues_from_result',
    'has_low_confidence'
]