# backend/main.py
import os
from dotenv import load_dotenv
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime
from fastapi.responses import JSONResponse

# Load environment
load_dotenv()

# Import config and database
from config import Config
from database import get_supabase_client

# ==========================================
# IMPORT ALL ROUTERS
# ==========================================

# Public/General routes
from routes import (
    waitlist,
    upload,
    reports,
    glossary,
    users,
    notifications,
    documents,
    drafts,
    reference,
    logs,
    emissions,
    feedback,
    drafts_enhanced,
)

# Admin routes
from routes.admin import (
    staff,
    defra,
    extraction,
    reviews,
    assignments,
    permissions,
    workload,
    beta,
    audit,
    review_history,
    staff_enhanced,
    admin_bulk,
    email_templates,
    admin_analytics,
    settings,
)

# Admin logs (renamed to avoid conflict)
from routes.admin import logs as admin_logs


# Organization routes
from routes.organizations import (
    management,
    members,
    assets,
    data,
    analytics,
    dashboard,
    files,
    team,
    metadata,
    exports,
    bulk as org_bulk,
)

# Document activity routes
from routes.documents import activity as document_activity

# ==========================================
# FASTAPI APP INITIALIZATION
# ==========================================

app = FastAPI(
    title=Config.APP_NAME,
    version=Config.APP_VERSION,
    description="CarbonTally API for carbon emissions tracking and reporting",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_tags=[
        # Health & System
        {
            "name": "Health",
            "description": "Health check and system status endpoints"
        },
        {
            "name": "System",
            "description": "System health, performance, and usage metrics"
        },
        
        # Public/General
        {
            "name": "Waitlist",
            "description": "Public waitlist management"
        },
        {
            "name": "Upload",
            "description": "File upload and processing endpoints"
        },
        {
            "name": "Reports",
            "description": "Report generation (SECR, CSRD, ISSB)"
        },
        {
            "name": "Glossary",
            "description": "Glossary management"
        },
        {
            "name": "User Management",
            "description": "User profile and authentication"
        },
        {
            "name": "Notifications",
            "description": "Email notifications"
        },
        {
            "name": "Feedback",
            "description": "User feedback collection and management"
        },
        
        # Admin
        {
            "name": "Admin - Staff Management",
            "description": "Staff member management (admin only)"
        },
        {
            "name": "Admin - Staff Performance",
            "description": "Staff performance metrics and activity tracking"
        },
        {
            "name": "Admin - DEFRA Factor Management",
            "description": "DEFRA factor management (admin only)"
        },
        {
            "name": "Admin - Extraction Management",
            "description": "Extraction approval and review (admin/data approver)"
        },
        {
            "name": "Admin - Reviews & Assignments",
            "description": "Review queue and assignment management"
        },
        {
            "name": "Admin - Workload",
            "description": "Staff workload and queue settings"
        },
        {
            "name": "Admin - Permissions",
            "description": "Role and permission management"
        },
        {
            "name": "Admin - Beta Management",
            "description": "Beta access code and user management"
        },
        {
            "name": "Admin - Audit",
            "description": "System audit and activity logs"
        },
        {
            "name": "Admin - Review History",
            "description": "Review assignment history and audit trail"
        },
        {
            "name": "Admin - Logs",
            "description": "Email and processing logs"
        },
        {
            "name": "Admin - Bulk Operations",
            "description": "Bulk operations for organizations and documents"
        },
        {
            "name": "Admin - Email Templates",
            "description": "Email template management"
        },
        {
            "name": "Admin - Analytics",
            "description": "System analytics and health metrics"
        },
        
        # Organization
        {
            "name": "Organization Management",
            "description": "Organization CRUD operations"
        },
        {
            "name": "Organization Metadata",
            "description": "Organization metadata management (financial, employee, sustainability)"
        },
        {
            "name": "Organization Members",
            "description": "Organization member management"
        },
        {
            "name": "Organization Team",
            "description": "Team member management"
        },
        {
            "name": "Organization Assets",
            "description": "Facility and asset management"
        },
        {
            "name": "Organization Data",
            "description": "Emissions data management"
        },
        {
            "name": "Organization Analytics",
            "description": "Analytics and insights"
        },
        {
            "name": "Organization Dashboard",
            "description": "Dashboard summaries"
        },
        {
            "name": "Organization Files",
            "description": "File management"
        },
        {
            "name": "Organization Exports",
            "description": "Data export management"
        },
        {
            "name": "Organization Bulk Operations",
            "description": "Bulk operations for members and assets"
        },
        
        # Documents
        {
            "name": "Documents",
            "description": "Document management"
        },
        {
            "name": "Documents - Activity",
            "description": "Document activity and customer reviews"
        },
        
        # Drafts
        {
            "name": "Drafts",
            "description": "Draft management"
        },
        {
            "name": "Drafts - Enhanced",
            "description": "Enhanced draft management with sections and progress"
        },
        
        # Other
        {
            "name": "Emissions",
            "description": "Emissions data management"
        },
        {
            "name": "Reference Data",
            "description": "Reference data (units, fuel types, etc.)"
        },
        {
            "name": "Logs",
            "description": "System logs and activity"
        },
    ]
)

# ==========================================
# CORS CONFIGURATION
# ==========================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=Config.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
    allow_headers=[
        "Authorization",
        "Content-Type",
        "Accept",
        "Origin",
        "X-Requested-With",
    ],
    expose_headers=["Content-Disposition"],
    max_age=600,  # Cache preflight requests for 10 minutes
)


# ==========================================
# INCLUDE ALL ROUTERS
# ==========================================

# Public/General routes
app.include_router(waitlist.router)
app.include_router(upload.router)
app.include_router(reports.router)
app.include_router(glossary.router)
app.include_router(users.router)
app.include_router(notifications.router)
app.include_router(documents.router)
app.include_router(reference.router)
app.include_router(drafts.router)
app.include_router(logs.router)
app.include_router(emissions.router)
app.include_router(feedback.router)
app.include_router(drafts_enhanced.router)

# Admin routes
app.include_router(staff.router)
app.include_router(staff_enhanced.router)
app.include_router(defra.router)
app.include_router(extraction.router)
app.include_router(reviews.router)
app.include_router(assignments.router)
app.include_router(permissions.router)
app.include_router(workload.router)
app.include_router(beta.router)
app.include_router(audit.router)
app.include_router(review_history.router)
app.include_router(admin_logs.router)
app.include_router(admin_bulk.router)
app.include_router(email_templates.router)
app.include_router(admin_analytics.router)
app.include_router(settings.router)

# Organization routes
app.include_router(management.router)
app.include_router(members.router)
app.include_router(assets.router)
app.include_router(data.router)
app.include_router(analytics.router)
app.include_router(dashboard.router)
app.include_router(files.router)
app.include_router(team.router)
app.include_router(metadata.router)
app.include_router(exports.router)
app.include_router(org_bulk.router)

# Document activity routes
app.include_router(document_activity.router)


# ==========================================
# ROOT ENDPOINTS
# ==========================================

@app.on_event("startup")
async def startup_event():
    print("🚀 Starting CarbonTally API...")
    print(f"📋 CORS Allowed Origins: {Config.ALLOWED_ORIGINS}")
    print(f"🔧 CORS Allow Credentials: {Config.CORS_ALLOW_CREDENTIALS}")
    
    # Count registered routes
    routes_count = len(app.routes)
    print(f"📊 Total routes registered: {routes_count}")

@app.get("/", tags=["Health"])
async def root():
    """
    Root endpoint.
    Returns basic service information.
    """
    return {
        "message": Config.APP_NAME,
        "version": Config.APP_VERSION,
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "documentation": "/docs",
        "api_version": "v3",
        "routes_count": len(app.routes)
    }

@app.get("/health", tags=["Health"])
async def health_check():
    """
    Health check endpoint.
    Verifies database connectivity and service status.
    """
    try:
        supabase = get_supabase_client()
        # Test connection
        test = supabase.table("glossary").select("count", count="exact").limit(1).execute()
        supabase_connected = True
    except Exception as e:
        print(f"⚠️ Health check error: {e}")
        supabase_connected = False
    
    return {
        "status": "healthy" if supabase_connected else "degraded",
        "service": Config.APP_NAME,
        "version": Config.APP_VERSION,
        "timestamp": datetime.now().isoformat(),
        "supabase_connected": supabase_connected,
        "components": {
            "database": {
                "status": "connected" if supabase_connected else "disconnected",
                "timestamp": datetime.now().isoformat()
            },
            "api": {
                "status": "running",
                "version": Config.APP_VERSION,
                "routes": len(app.routes)
            }
        }
    }

@app.get("/routes", tags=["Health"])
async def list_routes():
    """
    List all registered routes (for debugging).
    """
    routes = []
    for route in app.routes:
        routes.append({
            "path": route.path,
            "methods": list(route.methods) if hasattr(route, 'methods') else [],
            "name": route.name if hasattr(route, 'name') else None
        })
    
    return {
        "total_routes": len(routes),
        "routes": sorted(routes, key=lambda x: x['path'])
    }

@app.get("/test-upload", tags=["Health"])
async def test_upload():
    """
    Test endpoint for file uploads.
    Returns available upload endpoints.
    """
    return {
        "status": "ready",
        "message": "File upload endpoints available",
        "endpoints": [
            {
                "path": "/upload-csv",
                "method": "POST",
                "description": "Upload and process CSV/Excel files"
            },
            {
                "path": "/upload-pdf",
                "method": "POST",
                "description": "Upload and process PDF files"
            },
            {
                "path": "/upload-batch",
                "method": "POST",
                "description": "Batch upload multiple files (premium)"
            },
            {
                "path": "/repair-pdf",
                "method": "POST",
                "description": "Repair corrupted PDF with OCR"
            }
        ],
        "limits": {
            "max_file_size_mb": 50,
            "max_batch_files": 20,
            "max_batch_size_mb": 200
        }
    }

# ==========================================
# ERROR HANDLERS
# ==========================================

@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    """
    Custom HTTP exception handler for consistent error responses.
    """
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "success": False,
            "error": {
                "code": exc.status_code,
                "message": exc.detail,
                "timestamp": datetime.now().isoformat(),
                "path": request.url.path
            }
        }
    )

@app.exception_handler(Exception)
async def generic_exception_handler(request, exc):
    """
    Generic exception handler for unhandled errors.
    """
    print(f"❌ Unhandled exception: {exc}")
    import traceback
    traceback.print_exc()
    
    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "error": {
                "code": 500,
                "message": str(exc),
                "timestamp": datetime.now().isoformat(),
                "path": request.url.path
            }
        }
    )


# ==========================================
# SHUTDOWN EVENT
# ==========================================

@app.on_event("shutdown")
async def shutdown_event():
    """
    Clean up on application shutdown.
    """
    print("🛑 Shutting down CarbonTally API...")
    # Add any cleanup logic here (e.g., close database connections)


# ==========================================
# RUN APPLICATION
# ==========================================

if __name__ == "__main__":
    import uvicorn
    
    # Get port from environment or use default
    port = int(os.getenv("PORT", 8000))
    host = os.getenv("HOST", "0.0.0.0")
    reload = os.getenv("RELOAD", "true").lower() == "true"
    
    print(f"🚀 Starting CarbonTally API v{Config.APP_VERSION}")
    print(f"📍 Host: {host}:{port}")
    print(f"🔄 Reload: {reload}")
    print(f"📚 API Documentation: http://{host}:{port}/docs")
    
    uvicorn.run(
        "main:app",
        host=host,
        port=port,
        reload=reload,
        log_level="info",
        access_log=True
    )